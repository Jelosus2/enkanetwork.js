"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.costumes = void 0;
exports.costumes = {
    "undefined": {
        "sideIconName": "UI_AvatarIcon_Side_LisaCostumeStudentin",
        "icon": "UI_AvatarIcon_LisaCostumeStudentin",
        "art": "UI_Costume_LisaCostumeStudentin"
    }
};
